
#ifndef DATOS_H
#define DATOS_H

void imprimir(char *);
char * limpiar_cadena(char *arreglo_dato);
char * limpiar_c();

#endif